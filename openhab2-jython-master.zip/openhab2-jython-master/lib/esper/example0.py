import esper.java

from com.espertech.esper.client import EPServiceProviderManager
print EPServiceProviderManager