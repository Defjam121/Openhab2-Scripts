# About
This project provides some tools for Ubiquiti Networks mPower devices.

[nocontroller](nocontroller) Disables the controller connection attempts.

[MQTT client](mqtt/client) Provides an MQTT client.

[Thermostat](mqtt/thermostat) A simple thermostat script.